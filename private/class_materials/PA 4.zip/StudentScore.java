class StudentScore {
  public static void main (String[] arguments) {
    String[] names = {
      "Ben", "Bruce", "Justin", "Heather", "Austin", "Annie",
      "James", "Jenny", "Jimmy", "Paul"
    };

    int[] scores = {
      60, 63, 94, 94, 85, 100,
      97, 80, 57, 75
    };

    // Create 2 new arrays which will hold the sorted values
    String[] sortedNames = new String[names.length];
    int[] sortedScores = new int[scores.length];


    // Sort the list of scores and insert each sorted element individually
    // into the empty sorted arrays we created
    for (int i = 0; i < scores.length; i++) {

      // Delete this Print Statement before you turn in your assignment
      System.out.println("Name: " + names[i] + " - Score: " + scores[i]);


    }

    // Once the arrays have been sorted, output the required print statements
    System.out.println("Final Score Summary:");

    // Print out the highest score
    System.out.println("Top Score: ");

    // Print out the lowest score
    System.out.println("Lowest Score: ");

    //Print out the sorted list of scores from highest to lowest
    System.out.println("Sorted Score List:");
    
  }
}